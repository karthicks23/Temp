#!/usr/bin/env bash

WEB3J_PATH=/c/Tools/web3j-4.2.0/bin # <= Set the correct web3j package in your machine
SOLC_PATH=/c/Tools/solidity-windows

PROJECT_PATH=$PWD
CONTRACT_PATH=${PROJECT_PATH}/contracts
CONTRACT_BUILD=${PROJECT_PATH}/build

${SOLC_PATH}/solc ${CONTRACT_PATH}/Ebond.sol --bin --abi --optimize --overwrite -o ${CONTRACT_BUILD}

${WEB3J_PATH}/web3j solidity generate -a=${CONTRACT_BUILD}/Ebond.abi -b=${CONTRACT_BUILD}/Ebond.bin -p demo.hackathon.contracts -o ${PROJECT_PATH}/src/main/java
