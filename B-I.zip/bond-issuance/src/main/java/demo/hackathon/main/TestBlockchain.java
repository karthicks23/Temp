package demo.hackathon.main;

import demo.hackathon.contracts.Ebond;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.gas.ContractGasProvider;
import org.web3j.tx.gas.StaticGasProvider;

import java.math.BigInteger;

public class TestBlockchain {

    private static final String PRIVATE_KEY = "b3ef27288a9b2260a81fe5e86a783bdeb91f472abe28b79d5d9883852548c6fb";

    private final static BigInteger GAS_LIMIT = BigInteger.valueOf(6721975L);
    private final static BigInteger GAS_PRICE = BigInteger.valueOf(20000000000L);

    private final static String CONTRACT_ADDRESS = "0xb62d43a2b74bccb9be7edcf3c44d6be3b8841356";

    public static void main(String[] args) throws Exception {


        Web3j web3j = Web3j.build(new HttpService("http://127.0.0.1:7545"));

        Credentials credentials = getCredentialsFromPrivateKey();

        ContractGasProvider gasContractProvider = new StaticGasProvider(GAS_PRICE, GAS_LIMIT);

        //deployContract(web3j, credentials, gasContractProvider);

        printBondDetails(web3j, credentials, gasContractProvider);

    }

    private static void printBondDetails(Web3j web3j, Credentials credentials, ContractGasProvider gasContractProvider) throws Exception {
        Ebond ebond = Ebond.load(CONTRACT_ADDRESS, web3j, credentials, gasContractProvider);

        System.out.println("BOND NAME:"+ebond.getName().send());
    }

    private static void deployContract(Web3j web3j, Credentials credentials, ContractGasProvider gasContractProvider) throws Exception {
        String contractAddress = Ebond.deploy(web3j, credentials, gasContractProvider, "Smart-Bond",
                BigInteger.valueOf(1000),
                BigInteger.valueOf(5),
                BigInteger.valueOf(2)).send().getContractAddress();

        System.out.println("CONTRACT ADDRESS:" + contractAddress);
    }

    private static Credentials getCredentialsFromPrivateKey() {
        return Credentials.create(PRIVATE_KEY);
    }
}
