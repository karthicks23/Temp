package demo.hackathon.contracts;

import java.math.BigInteger;
import java.util.Arrays;
import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.2.0.
 */
public class Ebond extends Contract {
    private static final String BINARY = "608060405234801561001057600080fd5b506040516103783803806103788339810180604052608081101561003357600080fd5b81019080805164010000000081111561004b57600080fd5b8201602081018481111561005e57600080fd5b815164010000000081118282018710171561007857600080fd5b50506020820151604083015160609093015182519295509093509061009c57600080fd5b600082116100a957600080fd5b600083116100b657600080fd5b600081116100c357600080fd5b83516100d69060009060208701906100e9565b5060029290925560035560045550610184565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f1061012a57805160ff1916838001178555610157565b82800160010185558215610157579182015b8281111561015757825182559160200191906001019061013c565b50610163929150610167565b5090565b61018191905b80821115610163576000815560010161016d565b90565b6101e5806101936000396000f3fe608060405234801561001057600080fd5b50600436106100575760003560e01c8063124b65b41461005c57806317d7de7c146100765780637aafdeee146100f3578063cb57b0a5146100fb578063d561bf5314610103575b600080fd5b61006461010b565b60408051918252519081900360200190f35b61007e610111565b6040805160208082528351818301528351919283929083019185019080838360005b838110156100b85781810151838201526020016100a0565b50505050905090810190601f1680156100e55780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b6100646101a7565b6100646101ad565b6100646101b3565b60045490565b60008054604080516020601f600260001961010060018816150201909516949094049384018190048102820181019092528281526060939092909183018282801561019d5780601f106101725761010080835404028352916020019161019d565b820191906000526020600020905b81548152906001019060200180831161018057829003601f168201915b5050505050905090565b60015490565b60035490565b6002549056fea165627a7a72305820fbeb41c11ebbafc22ed36e66690109373b19ef41ed96992066786609668d4b100029";

    public static final String FUNC_GETTERM = "getTerm";

    public static final String FUNC_GETNAME = "getName";

    public static final String FUNC_GETTOTALBONDS = "getTotalBonds";

    public static final String FUNC_GETCOUPONRATE = "getCouponRate";

    public static final String FUNC_GETPARVALUE = "getParValue";

    @Deprecated
    protected Ebond(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected Ebond(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected Ebond(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected Ebond(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public RemoteCall<BigInteger> getTerm() {
        final Function function = new Function(FUNC_GETTERM, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<String> getName() {
        final Function function = new Function(FUNC_GETNAME, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<BigInteger> getTotalBonds() {
        final Function function = new Function(FUNC_GETTOTALBONDS, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> getCouponRate() {
        final Function function = new Function(FUNC_GETCOUPONRATE, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> getParValue() {
        final Function function = new Function(FUNC_GETPARVALUE, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    @Deprecated
    public static Ebond load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new Ebond(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static Ebond load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new Ebond(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static Ebond load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new Ebond(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static Ebond load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new Ebond(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<Ebond> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider, String _name, BigInteger _par, BigInteger _coupon, BigInteger _term) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_name), 
                new org.web3j.abi.datatypes.generated.Uint256(_par), 
                new org.web3j.abi.datatypes.generated.Uint256(_coupon), 
                new org.web3j.abi.datatypes.generated.Uint256(_term)));
        return deployRemoteCall(Ebond.class, web3j, credentials, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<Ebond> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider, String _name, BigInteger _par, BigInteger _coupon, BigInteger _term) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_name), 
                new org.web3j.abi.datatypes.generated.Uint256(_par), 
                new org.web3j.abi.datatypes.generated.Uint256(_coupon), 
                new org.web3j.abi.datatypes.generated.Uint256(_term)));
        return deployRemoteCall(Ebond.class, web3j, transactionManager, contractGasProvider, BINARY, encodedConstructor);
    }

    @Deprecated
    public static RemoteCall<Ebond> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit, String _name, BigInteger _par, BigInteger _coupon, BigInteger _term) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_name), 
                new org.web3j.abi.datatypes.generated.Uint256(_par), 
                new org.web3j.abi.datatypes.generated.Uint256(_coupon), 
                new org.web3j.abi.datatypes.generated.Uint256(_term)));
        return deployRemoteCall(Ebond.class, web3j, credentials, gasPrice, gasLimit, BINARY, encodedConstructor);
    }

    @Deprecated
    public static RemoteCall<Ebond> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit, String _name, BigInteger _par, BigInteger _coupon, BigInteger _term) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_name), 
                new org.web3j.abi.datatypes.generated.Uint256(_par), 
                new org.web3j.abi.datatypes.generated.Uint256(_coupon), 
                new org.web3j.abi.datatypes.generated.Uint256(_term)));
        return deployRemoteCall(Ebond.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, encodedConstructor);
    }
}
